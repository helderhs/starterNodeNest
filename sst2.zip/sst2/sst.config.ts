/// <reference path="./.sst/platform/config.d.ts" />

export default $config({
  app(input) {
    return {
      name: "express-api",
      // removal: input?.stage === "production" ? "retain" : "remove",
      removal: "remove",
      protect: ["production"].includes(input?.stage),
      home: "aws",
      providers: {
        aws: {
          region: "us-east-1",
          profile: "helder", // Seu perfil AWS
        },
      },
    };
  },
  //***************
  // APENAS API COM FARGATE ESCALAVEIS
  //***************
  async run() {
    const vpc = new sst.aws.Vpc("MyVpc");
    const cluster = new sst.aws.Cluster("MyCluster", { vpc });

    new sst.aws.Service("API", {
      cluster,
      memory: '0.5 GB',
      cpu: '0.25 vCPU',
      scaling: {
        min: 1,
        max: 1,
        // cpuUtilization: 50,
        // memoryUtilization: 80,
      },
      transform: {
        target: {
          healthCheck: {
            enabled: true,
            path: "/health",
            protocol: "HTTP",
            healthyThreshold: 2,
            unhealthyThreshold: 3,
            timeout: 5,
            interval: 30,
            matcher: "200",
          }
        },
      },
      capacity: {
        fargate: {base: 1, weight: 1 },
        // spot: {weight: 1}
      },
      loadBalancer: {
        rules: [{ listen: "80/http", forward: "3000/http" }],
      },
      dev: {
        command: "npm run dev",
      },
    });

    // return {
    //   api: api.url,
    // };
  },

  //***************
  // LAMBDA
  //***************
  // async run() {
  //   new sst.Api("Api", {
  //     routes: {
  //       "ANY /{proxy+}": "src/index.lambda",  // OBRIGATORIO LIB serverlessExpress
  //     },
  //     defaults: {
  //       function: {
  //         memorySize: 512,
  //         timeout: 10,
  //         environment: {
  //           // variáveis de ambiente aqui
  //         },
  //       },
  //     },
  //   });
  // },
});

