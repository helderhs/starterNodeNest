import express from 'express';
import cors from 'cors';

const app = express();
const PORT = process.env.PORT || 3000;

// CORS - permitir todas as origens em desenvolvimento
app.use(cors({
    origin: process.env.NODE_ENV === 'production'
        ? ['https://yourdomain.com'] // substitua pelo seu domínio
        : true, // permite todas as origens em desenvolvimento
    credentials: true
}));

// Middleware para parsing JSON
app.use(express.json());

// Middleware para logs
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});

// Dados de exemplo (em produção, você usaria um banco de dados)
let usuarios = [
    { id: 1, nome: 'João', email: 'joao@email.com' },
    { id: 2, nome: 'Maria', email: 'maria@email.com' },
    { id: 3, nome: 'Pedro', email: 'pedro@email.com' }
];

// Health check - OBRIGATÓRIO para ALB
app.get('/', (req, res) => {
    res.status(200).json({
        status: 'OK',
        mensagem: 'Bem-vindo à API Express2!',
        timestamp: new Date().toISOString(),
        uptime: process.uptime()
    });
});

// Health check alternativo
app.get('/health', (req, res) => {
    res.status(200).json({
        status: 'healthy',
        timestamp: new Date().toISOString()
    });
});

// GET - Listar todos os usuários
app.get('/usuarios', (req, res) => {
    res.json({
        success: true,
        data: usuarios,
        count: usuarios.length
    });
});

// GET - Buscar usuário por ID
app.get('/usuarios/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const usuario = usuarios.find(u => u.id === id);

    if (!usuario) {
        return res.status(404).json({
            success: false,
            erro: 'Usuário não encontrado'
        });
    }

    res.json({
        success: true,
        data: usuario
    });
});

// POST - Criar novo usuário
app.post('/usuarios', (req, res) => {
    const { nome, email } = req.body;

    if (!nome || !email) {
        return res.status(400).json({
            success: false,
            erro: 'Nome e email são obrigatórios'
        });
    }

    const novoUsuario = {
        id: Math.max(...usuarios.map(u => u.id), 0) + 1,
        nome,
        email
    };

    usuarios.push(novoUsuario);
    res.status(201).json({
        success: true,
        data: novoUsuario
    });
});

// PUT - Atualizar usuário
app.put('/usuarios/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const { nome, email } = req.body;

    const usuarioIndex = usuarios.findIndex(u => u.id === id);

    if (usuarioIndex === -1) {
        return res.status(404).json({
            success: false,
            erro: 'Usuário não encontrado'
        });
    }

    if (!nome || !email) {
        return res.status(400).json({
            success: false,
            erro: 'Nome e email são obrigatórios'
        });
    }

    usuarios[usuarioIndex] = { id, nome, email };
    res.json({
        success: true,
        data: usuarios[usuarioIndex]
    });
});

// DELETE - Deletar usuário
app.delete('/usuarios/:id', (req, res) => {
    const id = parseInt(req.params.id);
    const usuarioIndex = usuarios.findIndex(u => u.id === id);

    if (usuarioIndex === -1) {
        return res.status(404).json({
            success: false,
            erro: 'Usuário não encontrado'
        });
    }

    usuarios.splice(usuarioIndex, 1);
    res.json({
        success: true,
        message: 'Usuário deletado com sucesso'
    });
});

// Middleware de tratamento de erros
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({
        success: false,
        erro: 'Erro interno do servidor',
        message: process.env.NODE_ENV === 'development' ? err.message : 'Internal server error'
    });
});

// Middleware para rotas não encontradas
app.use('*', (req, res) => {
    res.status(404).json({
        success: false,
        erro: 'Rota não encontrada',
        path: req.originalUrl
    });
});

// IMPORTANTE: Para Fargate, escute em 0.0.0.0
const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 Servidor rodando na porta ${PORT}`);
    console.log(`📍 Environment: ${process.env.NODE_ENV || 'development'}`);
    console.log(`🌐 Acesse: http://0.0.0.0:${PORT}`);
});

// Graceful shutdown
const gracefulShutdown = () => {
    console.log('📴 Recebido sinal de shutdown, finalizando servidor...');
    server.close(() => {
        console.log('✅ Servidor finalizado com sucesso');
        process.exit(0);
    });
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Para Lambda (descomente se quiser usar Lambda)
// import serverlessExpress from "@vendia/serverless-express";
// export const lambda = serverlessExpress({ app });